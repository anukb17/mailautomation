from django.contrib import admin
from mailautomationapp.models import UserDetails
# Register your models here.

admin.site.register(UserDetails)